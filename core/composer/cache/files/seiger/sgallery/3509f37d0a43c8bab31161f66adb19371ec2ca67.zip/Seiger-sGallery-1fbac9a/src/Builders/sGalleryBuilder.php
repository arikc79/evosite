<?php namespace Seiger\sGallery\Builders;

use Illuminate\Support\Facades\Log;
use Illuminate\View\View;
use Seiger\sGallery\Controllers\sGalleryController;
use Seiger\sGallery\Models\sGalleryModel;
use Seiger\sGallery\sGallery;
use Spatie\Image\Enums\CropPosition;
use Spatie\Image\Enums\Fit;
use Spatie\Image\Enums\ImageDriver;
use Spatie\Image\Image;

/**
 * Class sGalleryBuilder
 *
 * A fluent builder class for configuring and retrieving gallery data with comprehensive
 * image manipulation capabilities. This class provides a chainable interface for:
 *
 * - Gallery view configuration (tabs, sections, downloads)
 * - File manipulation (resizing, cropping, format conversion)
 * - Browser-based format detection (AVIF, WebP, JPEG)
 * - Image processing with transparency support
 * - Caching and optimization
 */
class sGalleryBuilder
{
    protected string $mode = 'view';
    protected string $viewType = sGalleryModel::VIEW_SECTION;
    protected string $itemType = 'resource';
    protected string $idType = 'i';
    protected ?string $blockName = '1';
    protected ?int $documentId = null;
    protected int $quality = 100;
    protected bool $qualityExplicit = false;
    protected ?string $lang = null;
    protected ?\Illuminate\Database\Eloquent\Builder $query = null;
    protected ?\Illuminate\Database\Eloquent\Collection $files = null;
    protected ?string $file = null;
    protected ?array $params = [];
    protected ?bool $sourceHasAlpha = null;
    protected array $alphaDetectionCache = [];

    /**
     * Cached AVIF support driver (null = not checked, 'imagick' = ImageMagick supports AVIF, 'gd' = GD supports AVIF, false = no support)
     *
     * @var string|false|null
     */
    protected static $avifSupportDriver = null;

    /**
     * Set the mode for the builder (e.g., 'view' or 'collections').
     *
     * @param string $mode Mode for the builder, e.g., 'collections' or 'view'.
     * @return $this
     */
    public function setMode(string $mode): self
    {
        if ($mode == 'collections') {
            $this->initQuery();
        }
        $this->mode = $mode;
        return $this;
    }

    /**
     * Set the view type.
     *
     * @param string $viewType View type (e.g., tab, section).
     * @return $this
     */
    public function viewType(string $viewType): self
    {
        if (in_array($viewType, [
            sGalleryModel::VIEW_TAB,
            sGalleryModel::VIEW_SECTION,
            sGalleryModel::VIEW_SECTION_DOWNLOADS
        ])) {
            $this->viewType = $viewType;
        }
        return $this;
    }

    /**
     * Set the item type (resource type).
     *
     * @param string $itemType Resource type (e.g., 'resource', 'product', 'gallery').
     * @return $this
     */
    public function itemType(string $itemType): self
    {
        $this->itemType = $itemType;
        return $this;
    }

    /**
     * Set the document ID type.
     *
     * @param string $idType Document ID type.
     * @return $this
     */
    public function idType(string $idType): self
    {
        $this->idType = $idType;
        return $this;
    }

    /**
     * Set the block name.
     *
     * @param string $blockName Name of the block.
     * @return $this
     */
    public function blockName(string $blockName): self
    {
        $this->blockName = $blockName;
        return $this;
    }

    /**
     * Set the block name to null and return the builder instance.
     * Used to retrieve all files without filtering by block name.
     *
     * @return $this
     */
    public function all(): self
    {
        $this->blockName = null;
        return $this;
    }

    /**
     * Set the document ID.
     *
     * @param int $documentId ID of the document.
     * @return $this
     */
    public function documentId(int $documentId): self
    {
        $this->documentId = $documentId;
        return $this;
    }

    /**
     * Set the language for the query.
     *
     * @param string $lang Language code (e.g., 'en', 'uk').
     * @return $this
     */
    public function lang(string $lang): self
    {
        $this->lang = $lang;
        return $this;
    }

    /**
     * Set the format of the image output.
     *
     * @param string $format Image format (e.g., 'jpg', 'webp').
     * @return $this
     */
    public function format(string $format): self
    {
        $supportedFormats = ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif'];
        $format = strtolower($format);

        if (in_array($format, $supportedFormats)) {
            $this->params['format'] = $format;
        }

        return $this;
    }

    /**
     * Set the quality for the image output.
     *
     * @param int $quality Quality percentage (e.g., 80).
     * @return $this
     */
    public function quality(int $quality): self
    {
        $this->qualityExplicit = true;
        $this->quality = max(1, min(100, $quality));
        return $this;
    }

    /**
     * Sharpen the processed image after resize/crop transformations.
     *
     * @param float $amount Sharpen amount from 0 to 100.
     * @return $this
     */
    public function sharpen(float $amount): self
    {
        $this->params['sharpen'] = max(0, min(100, $amount));
        return $this;
    }

    /**
     * Run Spatie image optimizer after the processed image is saved.
     *
     * @param bool $optimize Whether to optimize the output image.
     * @return $this
     */
    public function optimize(bool $optimize = true): self
    {
        $this->params['optimize'] = $optimize;
        return $this;
    }

    /**
     * Set the resize dimensions for the image.
     *
     * @param int $width Width of the image.
     * @param int|null $height Height of the image (optional, defaults to the width if not provided).
     * @return $this
     */
    public function resize(int $width, int|null $height = null): self
    {
        $height = $height ?: $width;
        $this->params['w'] = max(1, $width);
        $this->params['h'] = max(1, $height);
        return $this;
    }

    /**
     * Set the fit method and dimensions for the image.
     *
     * @param string $method Fit method (e.g., 'crop', 'contain').
     * @param int $width Width of the image.
     * @param int|null $height Height of the image (optional, defaults to the width if not provided).
     * @return $this
     */
    public function fit(string $method, int $width, int|null $height = null): self
    {
        $height = $height ?: $width;

        $fitMethods = [
            'crop' => Fit::Crop,
            'contain' => Fit::Contain,
            'max' => Fit::Max,
            'fill' => Fit::Fill,
            'stretch' => Fit::Stretch,
            'fill-max' => Fit::FillMax,
        ];

        $this->params['fit'] = $fitMethods[$method] ?? Fit::Crop;
        $this->params['w'] = max(1, $width);
        $this->params['h'] = max(1, $height);

        return $this;
    }

    /**
     * Set the crop method and dimensions for the image.
     *
     * @param string $method Fit method (e.g., 'center', 'left', 'right').
     * @param int $width Width of the image.
     * @param int|null $height Height of the image (optional, defaults to the width if not provided).
     * @return $this
     */
    public function crop(string $method, int $width, int|null $height = null): self
    {
        $height = $height ?: $width;

        $cropMethods = [
            'topLeft' => CropPosition::TopLeft,
            'top' => CropPosition::Top,
            'topRight' => CropPosition::TopRight,
            'left' => CropPosition::Left,
            'center' => CropPosition::Center,
            'right' => CropPosition::Right,
            'bottomLeft' => CropPosition::BottomLeft,
            'bottom' => CropPosition::Bottom,
            'bottomRight' => CropPosition::BottomRight,
        ];

        $this->params['crop'] = $cropMethods[$method] ?? CropPosition::Center;
        $this->params['w'] = max(1, $width);
        $this->params['h'] = max(1, $height);
        return $this;
    }

    /**
     * Set focal crop with percentage-based center point.
     *
     * @param int $centerX The X coordinate of the focal center (0-100)
     * @param int $centerY The Y coordinate of the focal center (0-100)
     * @param int $width The width in pixels (minimum 1)
     * @param int|null $height The height in pixels (optional, defaults to width)
     * @return $this Fluent interface for method chaining
     *
     * @example
     * $builder->focalCrop(50, 30, 400, 300);
     */
    public function focalCrop(int $centerX, int $centerY, int $width, int|null $height = null): self
    {
        $height = $height ?: $width;

        $this->params['focalCenterX'] = max(0, $centerX);
        $this->params['focalCenterY'] = max(0, $centerY);
        $this->params['w'] = max(1, $width);
        $this->params['h'] = max(1, $height);
        return $this;
    }

    /**
     * Set manual crop with specific start coordinates.
     *
     * @param int $startX The X coordinate to start cropping from (minimum 0)
     * @param int $startY The Y coordinate to start cropping from (minimum 0)
     * @param int $width The width in pixels (minimum 1)
     * @param int|null $height The height in pixels (optional, defaults to width)
     * @return $this Fluent interface for method chaining
     *
     * @example
     * $builder->manualCrop(100, 50, 400, 300);
     */
    public function manualCrop(int $startX, int $startY, int $width, int|null $height = null): self
    {
        $height = $height ?: $width;

        $this->params['startX'] = max(0, $startX);
        $this->params['startY'] = max(0, $startY);
        $this->params['w'] = max(1, $width);
        $this->params['h'] = max(1, $height);
        return $this;
    }

    /**
     * Load files for the 'collections' mode if not already loaded.
     * This method initializes the query and filters files by language, document ID, item type, and block name (if provided).
     *
     * @return void
     */
    protected function loadFiles(): void
    {
        if (is_null($this->files)) {
            $this->initQuery();
            $query = $this->query->lang($this->lang ?? evo()->getLocale())
                ->whereParent($this->documentId ?? evo()->documentIdentifier)
                ->whereItemType($this->itemType);

            if ($this->blockName) {
                $query->whereBlock($this->blockName);
            }

            $this->files = $query->orderBy('position')->get();
        }
    }

    /**
     * Execute the query and return the collection of files.
     *
     * @return \Illuminate\Database\Eloquent\Collection|\Seiger\sGallery\Models\sGalleryModel[]
     */
    public function get(): \Illuminate\Database\Eloquent\Collection
    {
        $this->loadFiles();
        $files = $this->files;
        $this->resetBuilder();
        return $files;
    }

    /**
     * Get the file by its position in the collection.
     *
     * @param int $index Position index (1-based).
     * @return \Seiger\sGallery\Models\sGalleryModel|null
     */
    public function eq(int $index): ?\Seiger\sGallery\Models\sGalleryModel
    {
        $this->loadFiles();
        $files = $this->files->get($index - 1);
        $this->resetBuilder();
        return $files;
    }

    /**
     * Get the URL of the processed file (resized, formatted).
     *
     * @return string URL of the processed image or 'no image' placeholder.
     */
    public function getFile(): string
    {
        if (($this->file !== null && file_exists(EVO_BASE_PATH . $this->file)) || sGallery::hasLink($this->file)) {
            $extension = strtolower(pathinfo(EVO_BASE_PATH . $this->file, PATHINFO_EXTENSION));

            if ($this->params !== null && !in_array($extension, ['svg'])) {
                $imageName = str_replace('.' . pathinfo($this->file, PATHINFO_EXTENSION), '', pathinfo($this->file, PATHINFO_BASENAME));
                $imagePath = explode(DIRECTORY_SEPARATOR, pathinfo($this->file, PATHINFO_DIRNAME));
                $chacheFile = sGalleryModel::CACHE_DIR;

                foreach ($imagePath as $path) {
                    $chacheFile .= is_numeric($path) ? $path : ($path[0] ?? '');
                }

                $chacheFile .= DIRECTORY_SEPARATOR;
                $format = $this->params['format'] ?? $this->getSupportedImageFormat();

                // Ensure format is supported (if AVIF was requested but not supported, fallback to WebP)
                if ($format === 'avif' && !$this->isAvifSupported()) {
                    $format = 'webp';
                }

                // Build cache filename with transformation parameters
                $ext = isset($this->params['fit']) ? strtolower($this->params['fit']->value) . '-' : '';
                $ext .= isset($this->params['crop']) ? strtolower($this->params['crop']->value) . '-' : '';
                $ext .= isset($this->params['focalCenterX']) ? 'focal' . $this->params['focalCenterX'] . '-' . $this->params['focalCenterY'] . '-' : '';
                $ext .= isset($this->params['w']) ? $this->params['w'] . 'x' . $this->params['h'] : '';
                $ext .= isset($this->params['sharpen']) && $this->params['sharpen'] > 0 ? '-sh' . $this->params['sharpen'] : '';
                $ext .= !empty($this->params['optimize']) ? '-opt' : '';
                $imageName .= (trim($ext) ? '-' . $ext : '') . '.' . $format;

                if (!file_exists(EVO_BASE_PATH . $chacheFile . $imageName)) {
                    if (!file_exists(EVO_BASE_PATH . $chacheFile)) {
                        mkdir(EVO_BASE_PATH . $chacheFile, octdec(evo()->getConfig('new_folder_permissions', '0777')), true);
                        chmod(EVO_BASE_PATH . $chacheFile, octdec(evo()->getConfig('new_folder_permissions', '0777')));
                    }

                    $temp = null;

                    try {
                        // Handle remote files vs local files
                        if (sGallery::hasLink($this->file)) {
                            try {
                                // Download remote file to temporary location
                                $fileContents = @file_get_contents($this->file);
                                if ($fileContents === false) {
                                    throw new \Exception("Failed to fetch remote file: " . $this->file);
                                }

                                $temp = tmpfile();
                                if (!$temp) {
                                    throw new \Exception("Failed to create temporary file.");
                                }

                                fwrite($temp, $fileContents);
                                $file = stream_get_meta_data($temp)['uri'];
                            } catch (\Exception $e) {
                                return sGalleryModel::NOIMAGE;
                            }
                        } else {
                            // Use local file path
                            $file = EVO_BASE_PATH . $this->file;
                        }

                        if (is_file($file)) {
                            $this->sourceHasAlpha = $this->detectAlphaChannelFromPath($file);
                        }

                        if (!$this->isProcessableImage($file)) {
                            throw new \RuntimeException("Unsupported or corrupted image data: " . $this->file);
                        }

                        // Use appropriate driver based on format and AVIF support
                        if ($format === 'avif') {
                            // Ensure AVIF support is checked and driver is determined
                            if (self::$avifSupportDriver === null) {
                                $this->isAvifSupported();
                            }

                            // Use the driver that supports AVIF
                            if (self::$avifSupportDriver === 'imagick') {
                                $image = Image::useImageDriver(ImageDriver::Imagick)->loadFile($file);
                            } elseif (self::$avifSupportDriver === 'gd') {
                                $image = Image::useImageDriver(ImageDriver::Gd)->loadFile($file);
                            } else {
                                // AVIF not supported, fallback to WebP
                                $format = 'webp';
                                $imageName = preg_replace('/\.avif$/i', '.webp', $imageName);
                                $image = Image::load($file);
                            }
                        } else {
                            $image = Image::load($file);
                        }

                        // Apply image transformations based on parameters
                        if (isset($this->params['fit']) && isset($this->params['w']) && isset($this->params['h'])) {
                            $image->fit($this->params['fit'], $this->params['w'], $this->params['h']);
                        } elseif (isset($this->params['crop']) && isset($this->params['w']) && isset($this->params['h'])) {
                            $image->crop($this->params['w'], $this->params['h'], $this->params['crop']);
                        } elseif (isset($this->params['focalCenterX']) && isset($this->params['focalCenterY']) && isset($this->params['w']) && isset($this->params['h'])) {
                            $image->focalCrop($this->params['w'], $this->params['h'], $this->params['focalCenterX'], $this->params['focalCenterY']);
                        } elseif (isset($this->params['startX']) && isset($this->params['startY']) && isset($this->params['w']) && isset($this->params['h'])) {
                            $image->manualCrop($this->params['w'], $this->params['h'], $this->params['startX'], $this->params['startY']);
                        } elseif (isset($this->params['w']) && isset($this->params['h'])) {
                            $image->width($this->params['w'])->height($this->params['h']);
                        }

                        if (isset($this->params['sharpen']) && $this->params['sharpen'] > 0) {
                            $image->sharpen($this->params['sharpen']);
                        }

                        if (!empty($this->params['optimize'])) {
                            $image->optimize();
                        }

                        // Handle AVIF format with custom transparency support
                        if ($format === 'avif') {
                            $image->quality($this->quality);

                            // Check if original file has transparency (PNG, GIF, WebP)
                            $originalExtension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                            $hasTransparency = in_array($originalExtension, ['png', 'gif', 'webp']);

                            $avifPath = EVO_BASE_PATH . $chacheFile . $imageName;
                            $avifCreated = false;

                            try {
                                if ($hasTransparency) {
                                    $this->saveAvifWithTransparency($image, $avifPath);
                                } else {
                                    $image->format($format)->save($avifPath);
                                }

                                // Verify AVIF file was created and is valid
                                if (file_exists($avifPath)) {
                                    $fileSize = filesize($avifPath);
                                    if ($fileSize > 100) {
                                        $avifCreated = true;
                                    } else {
                                        // File exists but is too small, likely failed
                                        @unlink($avifPath);
                                    }
                                }

                                if (!$avifCreated) {
                                    throw new \Exception('AVIF file creation failed or file is too small');
                                }
                            } catch (\Exception $e) {
                                // AVIF creation failed, fallback to WebP
                                Log::warning("AVIF creation failed, falling back to WebP: " . $e->getMessage());

                                // Clean up failed AVIF file if exists
                                if (file_exists($avifPath)) {
                                    @unlink($avifPath);
                                }

                                $format = 'webp';
                                $imageName = preg_replace('/\.avif$/i', '.webp', $imageName);
                                $this->saveWebpImage($image, EVO_BASE_PATH . $chacheFile . $imageName);
                            }
                        } else {
                            if ($format === 'webp') {
                                $this->saveWebpImage($image, EVO_BASE_PATH . $chacheFile . $imageName);
                            } else {
                                $image->quality($this->quality)->format($format)->save(EVO_BASE_PATH . $chacheFile . $imageName);
                            }
                        }
                        chmod(EVO_BASE_PATH . $chacheFile . $imageName, octdec(evo()->getConfig('new_file_permissions', '0666')));
                    } catch (\Exception $e) {
                        Log::error("Error sGallery: " . $e->getMessage() . "\n" . $e->getTraceAsString());
                    } finally {
                        if (is_resource($temp)) {
                            fclose($temp);
                        }
                    }
                }

                // Check if file exists and is valid
                $finalPath = EVO_BASE_PATH . $chacheFile . $imageName;
                if (file_exists($finalPath)) {
                    // Check if AVIF file is valid (not empty or corrupted)
                    if ($format === 'avif') {
                        $fileSize = filesize($finalPath);
                        // If AVIF file is too small (likely corrupted or empty), try WebP fallback
                        if ($fileSize < 100) { // Less than 100 bytes is suspicious
                            $webpImageName = preg_replace('/\.avif$/i', '.webp', $imageName);
                            $webpPath = EVO_BASE_PATH . $chacheFile . $webpImageName;

                            // Try to create WebP version
                            if (!file_exists($webpPath)) {
                                try {
                                    // Reload original and save as WebP
                                    $originalFile = sGallery::hasLink($this->file) ? $this->file : EVO_BASE_PATH . $this->file;
                                    if (sGallery::hasLink($this->file)) {
                                        $fileContents = @file_get_contents($this->file);
                                        if ($fileContents !== false) {
                                            $temp = tmpfile();
                                            fwrite($temp, $fileContents);
                                            $originalFile = stream_get_meta_data($temp)['uri'];
                                        }
                                    }

                                    if (is_file($originalFile)) {
                                        $webpImage = Image::load($originalFile);

                                        // Apply same transformations
                                        if (isset($this->params['fit']) && isset($this->params['w']) && isset($this->params['h'])) {
                                            $webpImage->fit($this->params['fit'], $this->params['w'], $this->params['h']);
                                        } elseif (isset($this->params['crop']) && isset($this->params['w']) && isset($this->params['h'])) {
                                            $webpImage->crop($this->params['w'], $this->params['h'], $this->params['crop']);
                                        } elseif (isset($this->params['focalCenterX']) && isset($this->params['focalCenterY']) && isset($this->params['w']) && isset($this->params['h'])) {
                                            $webpImage->focalCrop($this->params['w'], $this->params['h'], $this->params['focalCenterX'], $this->params['focalCenterY']);
                                        } elseif (isset($this->params['startX']) && isset($this->params['startY']) && isset($this->params['w']) && isset($this->params['h'])) {
                                            $webpImage->manualCrop($this->params['w'], $this->params['h'], $this->params['startX'], $this->params['startY']);
                                        } elseif (isset($this->params['w']) && isset($this->params['h'])) {
                                            $webpImage->width($this->params['w'])->height($this->params['h']);
                                        }

                                        if (isset($this->params['sharpen']) && $this->params['sharpen'] > 0) {
                                            $webpImage->sharpen($this->params['sharpen']);
                                        }

                                        if (!empty($this->params['optimize'])) {
                                            $webpImage->optimize();
                                        }

                                        $this->saveWebpImage($webpImage, $webpPath);
                                        chmod($webpPath, octdec(evo()->getConfig('new_file_permissions', '0666')));
                                    }

                                    if (isset($temp) && is_resource($temp)) {
                                        fclose($temp);
                                    }
                                } catch (\Exception $e) {
                                    // WebP creation failed, continue with AVIF
                                }
                            }

                            // Use WebP if it exists and is valid
                            if (file_exists($webpPath) && filesize($webpPath) > 100) {
                                $this->file = $chacheFile . $webpImageName;
                            } else {
                                // Use AVIF even if small (might be valid for very small images)
                                $this->file = $chacheFile . $imageName;
                            }
                        } else {
                            $this->file = $chacheFile . $imageName;
                        }
                    } else {
                        $this->file = $chacheFile . $imageName;
                    }
                } else {
                    return sGalleryModel::NOIMAGE;
                }
            }

            return EVO_SITE_URL . $this->file;
        }

        return sGalleryModel::NOIMAGE;
    }

    /**
     * Determine and return the first supported image format based on browser capabilities.
     *
     * @return string
     */
    public function getSupportedImageFormat(): string
    {
        $availableFormats = $this->buildFormatPreferenceList();

        if ($override = $this->getClientOverrideFormat($availableFormats)) {
            return $this->rememberSupportedImageFormat($override);
        }

        if (isset($_SESSION['supported_image_format']) && in_array($_SESSION['supported_image_format'], $availableFormats, true)) {
            return $_SESSION['supported_image_format'];
        }

        $cookieFormat = $this->normalizeFormat($_COOKIE['sgallery_supported_image_format'] ?? null);
        if ($cookieFormat !== null && in_array($cookieFormat, $availableFormats, true)) {
            return $this->rememberSupportedImageFormat($cookieFormat);
        }

        $supportedFormat = $this->detectSupportedImageFormat($availableFormats);

        return $this->rememberSupportedImageFormat($supportedFormat);
    }

    /**
     * Set the file path for the builder.
     *
     * @param string $input File path relative to the base path.
     * @return $this
     */
    public function file(string $input): self
    {
        $input = trim(str_replace([EVO_SITE_URL, EVO_BASE_PATH], '', $input), '/');
        $this->file = $input;
        $this->params = ['optimize' => true];
        return $this;
    }

    /**
     * Get the rendered gallery view.
     *
     * @return string Rendered view of the gallery.
     */
    public function getView(): string
    {
        $sGalleryController = new sGalleryController($this->viewType, $this->itemType, $this->idType, $this->blockName);
        $view = $sGalleryController->index();
        return $view instanceof View ? $view->render() : (string)$view;
    }

    /**
     * Render the view or return the processed file path as a string when treated like a string.
     *
     * @return string Rendered view or processed file path.
     */
    public function __toString(): string
    {
        try {
            $result = $this->file !== null ? $this->getFile() : $this->getView();
            $this->resetBuilder();
            return $result;
        } catch (\Exception $e) {
            return "Error sGallery: " . $e->getMessage();
        }
    }

    /**
     * Initialize the query if not already done and the mode is 'collections'.
     */
    protected function initQuery(): void
    {
        if (is_null($this->query) && $this->mode === 'collections') {
            $this->query = sGalleryModel::query();
        }
    }

    /**
     * Check and return the first supported image format from a list.
     *
     * @param array $formats List of formats to check.
     * @return string First supported format or 'jpg' by default.
     */
    protected function detectSupportedImageFormat(array $formats): string
    {
        if (empty($formats)) {
            return 'jpg';
        }

        if ($format = $this->detectSupportedFormatFromHeaders($formats)) {
            return $format;
        }

        if ($format = $this->guessSupportedFormatByUserAgent($formats)) {
            return $format;
        }

        $hasAlpha = $this->sourceHasAlphaChannel();

        if ($hasAlpha && in_array('png', $formats, true)) {
            return 'png';
        }

        if (!$hasAlpha && in_array('jpg', $formats, true)) {
            return 'jpg';
        }

        return reset($formats) ?: 'jpg';
    }

    /**
     * Build preferred format list based on source properties.
     *
     * @return array
     */
    private function buildFormatPreferenceList(): array
    {
        $hasAlpha = $this->sourceHasAlphaChannel();

        $formats = [];
        $formats[] = 'webp';

        if ($hasAlpha) {
            $formats[] = 'png';
            $formats[] = 'jpg';
        } else {
            $formats[] = 'jpg';
            $formats[] = 'png';
        }

        return array_values(array_unique($formats));
    }

    /**
     * Check if AVIF is actually supported by the server
     * Checks both ImageMagick and GD, as either can be compiled without AVIF support
     * Also determines which driver supports AVIF and caches it
     *
     * @return bool
     */
    protected function isAvifSupported(): bool
    {
        // Use cached result if available
        if (self::$avifSupportDriver !== null) {
            return self::$avifSupportDriver !== false;
        }

        // Check ImageMagick first (if available)
        if (extension_loaded('imagick')) {
            try {
                $imagick = new \Imagick();
                $formats = $imagick->queryFormats();
                // Check if AVIF is in the list of supported formats
                // Even if ImageMagick is installed, it might not support AVIF
                if (in_array('AVIF', $formats) || in_array('avif', $formats)) {
                    self::$avifSupportDriver = 'imagick';
                    return true;
                }
            } catch (\Exception $e) {
                // ImageMagick available but query failed, continue to GD check
            }
        }

        // Fallback to GD check
        if (function_exists('imageavif')) {
            if (function_exists('imagetypes')) {
                // Check if GD was compiled with AVIF support
                if ((imagetypes() & IMG_AVIF) !== 0) {
                    self::$avifSupportDriver = 'gd';
                    return true;
                }
            }
            // If imagetypes() not available, function exists but might not work
        }

        // No AVIF support found
        self::$avifSupportDriver = false;
        return false;
    }

    /**
     * Reset builder state for the next usage.
     *
     * @return void
     */
    protected function resetBuilder(): void
    {
        $this->query = null;
        $this->files = null;
        $this->file = null;
        $this->params = [];
        $this->sourceHasAlpha = null;
        $this->qualityExplicit = false;
        $this->alphaDetectionCache = [];
    }

    /**
     * Get the effective WebP output quality.
     *
     * WebP quality 100 can create unnecessarily heavy files, so the default
     * upper bound is normalized to 99 unless a lower quality is configured.
     *
     * @return int
     * @since 1.5.0
     */
    private function getWebpOutputQuality(): int
    {
        return $this->quality >= 100 ? 99 : $this->quality;
    }

    /**
     * Save the image as WebP with optional adaptive PageSpeed-friendly quality.
     *
     * Explicit quality settings keep the requested value, while optimized images
     * are saved with the highest tested quality that fits the estimated target size.
     *
     * @param \Spatie\Image\Image $image The image instance.
     * @param string $path The path where to save the WebP image.
     * @return void
     * @since 1.5.0
     */
    private function saveWebpImage(Image $image, string $path): void
    {
        if ($this->qualityExplicit || empty($this->params['optimize'])) {
            $image->quality($this->getWebpOutputQuality())->format('webp')->save($path);
            return;
        }

        $targetBytes = $this->getPageSpeedImageTargetBytes($image);
        $qualities = [99, 97, 95, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 82, 80];

        foreach ($qualities as $quality) {
            $image->quality($quality)->format('webp')->save($path);

            if (!file_exists($path)) {
                continue;
            }

            if (filesize($path) <= $targetBytes) {
                break;
            }
        }
    }

    /**
     * Estimate the target file size for PageSpeed image delivery checks.
     *
     * The estimate is based on rendered pixels and the Lighthouse/WebPageTest-style
     * bytes-per-pixel target used for modern image delivery recommendations.
     *
     * @param \Spatie\Image\Image $image The image instance.
     * @return int Estimated target size in bytes.
     * @since 1.5.0
     */
    private function getPageSpeedImageTargetBytes(Image $image): int
    {
        $pixels = max(1, $image->getWidth() * $image->getHeight());
        $displaySafetyFactor = 0.9;
        $targetBytesPerPixel = 2 / 12;

        return (int) ceil($pixels * $displaySafetyFactor * $targetBytesPerPixel) + 4096;
    }

    /**
     * Save image as AVIF with proper transparency support.
     *
     * @param \Spatie\Image\Image $image The image instance.
     * @param string $path The path where to save the image.
     * @return void
     */
    private function saveAvifWithTransparency($image, string $path): void
    {
        $originalFile = $this->file;
        $driverName = $image->driverName();
        $imageResource = $image->image();

        // If using ImageMagick, we can save directly without custom transparency handling
        if ($driverName === 'imagick') {
            $image->format('avif')->save($path);
            return;
        }

        // For GD driver, use custom transparency handling
        $gdImage = $imageResource;

        // Check if image has alpha channel
        $width = \imagesx($gdImage);
        $height = \imagesy($gdImage);
        $isTrueColor = \imageistruecolor($gdImage);
        $hasAlpha = false;

        if ($isTrueColor) {
            for ($x = 0; $x < min($width, 10); $x++) {
                for ($y = 0; $y < min($height, 10); $y++) {
                    $color = \imagecolorat($gdImage, $x, $y);
                    $alpha = ($color >> 24) & 0xFF;
                    if ($alpha < 255) {
                        $hasAlpha = true;
                        break 2;
                    }
                }
            }
        }

        // Check if original file has transparency before attempting custom approach
        $originalHasTransparency = false;
        $absoluteOriginalPath = $this->getAbsoluteSourcePath($originalFile);
        if ($absoluteOriginalPath !== null) {
            $originalHasTransparency = $this->detectAlphaChannelFromPath($absoluteOriginalPath);
        }

        // If Spatie Image lost transparency and original has transparency, try to reload original image directly
        if (!$hasAlpha && $originalHasTransparency && $absoluteOriginalPath !== null) {
            $originalPath = $absoluteOriginalPath;
            $originalImage = null;

            $extension = strtolower(pathinfo($originalPath, PATHINFO_EXTENSION));
            switch ($extension) {
                case 'png':
                    // For PNG, load without modifying alpha settings initially
                    $originalImage = \imagecreatefrompng($originalPath);
                    break;
                case 'jpg':
                case 'jpeg':
                    $originalImage = \imagecreatefromjpeg($originalPath);
                    break;
                case 'gif':
                    $originalImage = \imagecreatefromgif($originalPath);
                    break;
                case 'webp':
                    $originalImage = \imagecreatefromwebp($originalPath);
                    break;
            }

            if ($originalImage) {
                $originalWidth = \imagesx($originalImage);
                $originalHeight = \imagesy($originalImage);

                // For PNG, apply alpha settings first, then check
                if ($extension === 'png') {
                    \imagepalettetotruecolor($originalImage);
                    \imagealphablending($originalImage, false);
                    \imagesavealpha($originalImage, true);
                }

                // Check if original image has transparency
                $originalHasAlpha = false;

                // Check pixels for transparency detection
                for ($x = 0; $x < min($originalWidth, 50); $x++) {
                    for ($y = 0; $y < min($originalHeight, 50); $y++) {
                        $color = \imagecolorat($originalImage, $x, $y);
                        $alpha = ($color >> 24) & 0xFF;

                        if ($alpha < 255) { // Any transparency
                            $originalHasAlpha = true;
                            break 2;
                        }
                    }
                }

                $targetWidth = $width;
                $targetHeight = $height;
                $resizedImage = \imagecreatetruecolor($targetWidth, $targetHeight);

                // Preserve transparency - set transparent background
                \imagealphablending($resizedImage, false);
                \imagesavealpha($resizedImage, true);

                // Fill with transparent color
                $transparent = \imagecolorallocatealpha($resizedImage, 0, 0, 0, 127);
                \imagefill($resizedImage, 0, 0, $transparent);

                // Copy and resize with better transparency handling
                \imagealphablending($resizedImage, true);
                \imagecopyresampled(
                    $resizedImage, $originalImage,
                    0, 0, 0, 0,
                    $targetWidth, $targetHeight,
                    \imagesx($originalImage), \imagesy($originalImage)
                );
                \imagealphablending($resizedImage, false);

                \imagedestroy($originalImage);
                \imagedestroy($gdImage);
                $gdImage = $resizedImage;
            }
        }

        // Apply transparency fixes
        \imagepalettetotruecolor($gdImage);
        \imagealphablending($gdImage, false);
        \imagesavealpha($gdImage, true);

        $quality = $this->quality;
        if ($originalHasTransparency || $hasAlpha) {
            $this->markTransparentSource();
            if (!$this->qualityExplicit) {
                $quality = 100;
            }
        } else {
            $this->clearTransparentSource();
        }

        // Check if AVIF encoding is actually supported before attempting
        if (!function_exists('imageavif')) {
            \imagedestroy($gdImage);
            throw new \RuntimeException('imageavif() function is not available');
        }

        // Suppress warnings but check return value
        $result = @\imageavif($gdImage, $path, $quality);
        \imagedestroy($gdImage);

        // Check if file was created and has content
        if ($result === false || !file_exists($path) || filesize($path) < 100) {
            // Clean up failed file
            if (file_exists($path)) {
                @unlink($path);
            }
            throw new \RuntimeException('AVIF encoding failed or resulted in empty file');
        }
    }

    /**
     * Validate if file contains processable image data.
     *
     * @param string $filePath
     * @return bool
     */
    private function isProcessableImage(string $filePath): bool
    {
        if (!is_file($filePath)) {
            return false;
        }

        $size = @filesize($filePath);
        if ($size === false || $size === 0) {
            return false;
        }

        $finfo = function_exists('finfo_open') ? @finfo_open(FILEINFO_MIME_TYPE) : false;
        if ($finfo) {
            $mime = @finfo_file($finfo, $filePath);
            finfo_close($finfo);
            if (is_string($mime) && strpos(strtolower($mime), 'image/') === 0) {
                return true;
            }
        }

        $imageInfo = @getimagesize($filePath);
        if ($imageInfo !== false) {
            $mime = strtolower($imageInfo['mime'] ?? '');
            if ($mime !== '' && strpos($mime, 'image/') === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determine if current source image includes an alpha channel.
     *
     * @return bool
     */
    private function sourceHasAlphaChannel(): bool
    {
        if ($this->sourceHasAlpha !== null) {
            return $this->sourceHasAlpha;
        }

        $absolutePath = $this->getAbsoluteSourcePath();
        if ($absolutePath !== null) {
            $this->sourceHasAlpha = $this->detectAlphaChannelFromPath($absolutePath);
            return $this->sourceHasAlpha;
        }

        if ($this->file !== null) {
            $extension = strtolower(pathinfo($this->file, PATHINFO_EXTENSION));
            $this->sourceHasAlpha = in_array($extension, ['png', 'gif', 'webp'], true);
            return $this->sourceHasAlpha;
        }

        $this->sourceHasAlpha = false;
        return false;
    }

    /**
     * Persistently mark current source as containing transparency.
     *
     * @return void
     */
    private function markTransparentSource(): void
    {
        $this->sourceHasAlpha = true;
    }

    /**
     * Persistently mark current source as opaque.
     *
     * @return void
     */
    private function clearTransparentSource(): void
    {
        $this->sourceHasAlpha = false;
    }

    /**
     * Resolve absolute path for current or given relative file.
     *
     * @param string|null $relative
     * @return string|null
     */
    private function getAbsoluteSourcePath(?string $relative = null): ?string
    {
        $target = $relative ?? $this->file;

        if ($target === null || sGallery::hasLink($target)) {
            return null;
        }

        $target = ltrim($target, '/');

        $candidates = [
            EVO_BASE_PATH . $target,
            sGalleryModel::UPLOAD . $target,
        ];

        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        return null;
    }

    /**
     * Detect whether image at path uses transparency.
     *
     * @param string $path
     * @return bool
     */
    private function detectAlphaChannelFromPath(string $path): bool
    {
        if (!is_file($path)) {
            return false;
        }

        $stats = @stat($path);
        $cacheKey = (realpath($path) ?: $path) . '|' . ($stats['size'] ?? 0) . '|' . ($stats['mtime'] ?? 0);

        if (array_key_exists($cacheKey, $this->alphaDetectionCache)) {
            return $this->alphaDetectionCache[$cacheKey];
        }

        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $result = false;

        switch ($extension) {
            case 'png':
                $resource = @imagecreatefrompng($path);
                if ($resource) {
                    \imagealphablending($resource, true);
                    \imagesavealpha($resource, true);
                    $result = $this->hasTransparentPixel($resource);
                    \imagedestroy($resource);
                }
                break;
            case 'gif':
                $resource = @imagecreatefromgif($path);
                if ($resource) {
                    $transparentIndex = \imagecolortransparent($resource);
                    if ($transparentIndex >= 0) {
                        $result = true;
                    } else {
                        $result = $this->hasTransparentPixel($resource);
                    }
                    \imagedestroy($resource);
                }
                break;
            case 'webp':
                if (\function_exists('imagecreatefromwebp')) {
                    $resource = @imagecreatefromwebp($path);
                    if ($resource) {
                        $result = $this->hasTransparentPixel($resource);
                        \imagedestroy($resource);
                    }
                }
                break;
            default:
                $result = false;
        }

        $this->alphaDetectionCache[$cacheKey] = $result;

        return $result;
    }

    /**
     * Inspect GD resource for presence of transparent pixels.
     *
     * @param \GdImage|resource $resource
     * @return bool
     */
    private function hasTransparentPixel($resource): bool
    {
        if (!\is_resource($resource) && !($resource instanceof \GdImage)) {
            return false;
        }

        $width = \imagesx($resource);
        $height = \imagesy($resource);

        if ($width === 0 || $height === 0) {
            return false;
        }

        $sampleWidth = min($width, 100);
        $sampleHeight = min($height, 100);
        $stepX = max(1, (int)floor($width / $sampleWidth));
        $stepY = max(1, (int)floor($height / $sampleHeight));

        for ($x = 0; $x < $width; $x += $stepX) {
            for ($y = 0; $y < $height; $y += $stepY) {
                $color = \imagecolorat($resource, $x, $y);
                $alpha = ($color >> 24) & 0x7F;
                if ($alpha > 0) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Try to fetch preferred format provided by client.
     *
     * @param array $availableFormats
     * @return string|null
     */
    private function getClientOverrideFormat(array $availableFormats): ?string
    {
        $sources = [
            $_GET['sgallery-format'] ?? null,
            $_POST['sgallery-format'] ?? null,
            $_REQUEST['sgallery-format'] ?? null,
        ];

        foreach ($sources as $value) {
            $normalized = $this->normalizeFormat($value);
            if ($normalized !== null && in_array($normalized, $availableFormats, true)) {
                return $normalized;
            }
        }

        return null;
    }

    /**
     * Normalize common format aliases.
     *
     * @param mixed $value
     * @return string|null
     */
    private function normalizeFormat(mixed $value): ?string
    {
        if (!is_string($value) || $value === '') {
            return null;
        }

        $format = strtolower(trim($value));

        if ($format === 'jpeg') {
            $format = 'jpg';
        }

        return in_array($format, ['avif', 'webp', 'png', 'jpg', 'gif'], true) ? $format : null;
    }

    /**
     * Store supported format in session and cookie.
     *
     * @param string $format
     * @return string
     */
    private function rememberSupportedImageFormat(string $format): string
    {
        $_SESSION['supported_image_format'] = $format;

        $currentCookie = $this->normalizeFormat($_COOKIE['sgallery_supported_image_format'] ?? null);

        if ($currentCookie !== $format && !headers_sent()) {
            $cookieOptions = [
                'expires' => time() + (86400 * 30),
                'path' => '/',
                'samesite' => 'Lax',
            ];

            if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
                $cookieOptions['secure'] = true;
            }

            setcookie('sgallery_supported_image_format', $format, $cookieOptions);
        }

        return $format;
    }

    /**
     * Detect format support based on request headers.
     *
     * @param array $formats
     * @return string|null
     */
    private function detectSupportedFormatFromHeaders(array $formats): ?string
    {
        $headers = [];

        foreach (['HTTP_SEC_CH_ACCEPT', 'HTTP_ACCEPT'] as $headerName) {
            if (!empty($_SERVER[$headerName])) {
                $headers[] = strtolower($_SERVER[$headerName]);
            }
        }

        if (empty($headers)) {
            return null;
        }

        foreach ($headers as $header) {
            foreach ($formats as $format) {
                foreach ($this->mapFormatToMimeList($format) as $mime) {
                    if (strpos($header, $mime) !== false) {
                        return $format === 'jpeg' ? 'jpg' : $format;
                    }
                }
            }
        }

        return null;
    }

    /**
     * Provide MIME candidates for specific format.
     *
     * @param string $format
     * @return array
     */
    private function mapFormatToMimeList(string $format): array
    {
        return match ($format) {
            'avif' => ['image/avif'],
            'webp' => ['image/webp'],
            'png' => ['image/png'],
            'jpg' => ['image/jpeg', 'image/jpg'],
            default => ['image/' . $format],
        };
    }

    /**
     * Guess supported format using User-Agent heuristics.
     *
     * @param array $formats
     * @return string|null
     */
    private function guessSupportedFormatByUserAgent(array $formats): ?string
    {
        $userAgent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

        if ($userAgent === '') {
            return null;
        }

        $supportsAvif = false;
        $supportsWebp = false;

        $chromeVersion = $this->extractVersionFromUserAgent($userAgent, ['chrome/', 'crios/', 'crmo/']);
        if ($chromeVersion !== null) {
            if ($chromeVersion >= 85.0) {
                $supportsAvif = true;
            }
            if ($chromeVersion >= 32.0) {
                $supportsWebp = true;
            }
        }

        $edgeVersion = $this->extractVersionFromUserAgent($userAgent, ['edg/', 'edgios/']);
        if ($edgeVersion !== null) {
            if ($edgeVersion >= 85.0) {
                $supportsAvif = true;
            }
            if ($edgeVersion >= 18.0) {
                $supportsWebp = true;
            }
        }

        $operaVersion = $this->extractVersionFromUserAgent($userAgent, ['opr/', 'opera/']);
        if ($operaVersion !== null) {
            if ($operaVersion >= 71.0) {
                $supportsAvif = true;
            }
            if ($operaVersion >= 19.0) {
                $supportsWebp = true;
            }
        }

        $firefoxVersion = $this->extractVersionFromUserAgent($userAgent, ['firefox/', 'fxios/']);
        if ($firefoxVersion !== null) {
            if ($firefoxVersion >= 93.0) {
                $supportsAvif = true;
            }
            if ($firefoxVersion >= 65.0) {
                $supportsWebp = true;
            }
        }

        if ($this->isSafariUserAgent($userAgent)) {
            $safariVersion = $this->extractVersionFromUserAgent($userAgent, ['version/']);
            $iosVersion = $this->extractIosVersion($userAgent);

            if ($safariVersion !== null) {
                if ($safariVersion >= 16.0) {
                    $supportsAvif = true;
                }
                if ($safariVersion >= 14.0) {
                    $supportsWebp = true;
                }
            } elseif ($iosVersion !== null) {
                if ($iosVersion >= 16.0) {
                    $supportsAvif = true;
                }
                if ($iosVersion >= 14.0) {
                    $supportsWebp = true;
                }
            }
        }

        if (strpos($userAgent, 'samsungbrowser/') !== false) {
            $samsungVersion = $this->extractVersionFromUserAgent($userAgent, ['samsungbrowser/']);
            if ($samsungVersion !== null) {
                if ($samsungVersion >= 14.0) {
                    $supportsAvif = true;
                }
                if ($samsungVersion >= 5.0) {
                    $supportsWebp = true;
                }
            }
        }

        foreach ($formats as $format) {
            if ($format === 'avif' && $supportsAvif) {
                return 'avif';
            }

            if ($format === 'webp' && $supportsWebp) {
                return 'webp';
            }

            if ($format === 'png') {
                return 'png';
            }

            if (in_array($format, ['jpg', 'jpeg'], true)) {
                return 'jpg';
            }
        }

        return null;
    }

    /**
     * Extract numeric version from User-Agent markers.
     *
     * @param string $userAgent
     * @param array $markers
     * @return float|null
     */
    private function extractVersionFromUserAgent(string $userAgent, array $markers): ?float
    {
        foreach ($markers as $marker) {
            $position = strpos($userAgent, $marker);
            if ($position === false) {
                continue;
            }

            $versionString = substr($userAgent, $position + strlen($marker));
            if ($versionString === false) {
                continue;
            }

            if (preg_match('/^([0-9]+(?:\.[0-9]+)?)/', $versionString, $matches)) {
                return (float)$matches[1];
            }
        }

        return null;
    }

    /**
     * Determine if User-Agent represents Safari (desktop or iOS).
     *
     * @param string $userAgent
     * @return bool
     */
    private function isSafariUserAgent(string $userAgent): bool
    {
        if (strpos($userAgent, 'safari') === false) {
            return false;
        }

        $nonSafariMarkers = ['chrome', 'crios', 'crmo', 'fxios', 'ucbrowser', 'edg', 'opr/', 'opera', 'yabrowser'];
        foreach ($nonSafariMarkers as $marker) {
            if (strpos($userAgent, $marker) !== false) {
                return false;
            }
        }

        return true;
    }

    /**
     * Extract iOS version from User-Agent string.
     *
     * @param string $userAgent
     * @return float|null
     */
    private function extractIosVersion(string $userAgent): ?float
    {
        if (preg_match('/os\s(\d+)[._](\d+)/', $userAgent, $matches)) {
            return (float)($matches[1] . '.' . $matches[2]);
        }

        return null;
    }
}
